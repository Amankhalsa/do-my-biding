$(function() {

    $('.metismenu').metisMenu({
      toggle: false,
      triggerElement: '.card-header',
      parentTrigger: '.card',
      subMenu: '.card-body'
    });
  
  });
  
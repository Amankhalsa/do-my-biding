<?php
$getcat = DB::table('categories')->get();
$getlocation = DB::table('locations')->orderBy('name')->get();
$front_banner = DB::table('front_banners')->first();
$get_logo = DB::table('sitelogos')->first();
?>

<?php $__env->startSection('title', 'Add post' ); ?>
<?php $__env->startSection('home_content'); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>


<div class="headerHeight"></div>
<section>
    <div class="postAdCol">
        <div class="container">
            <form class="formStyle2" action="<?php echo e(route('store.front.post')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="postCardMain">
                    <div class="postHeader">
                        <h4>Post your free ad</h4>
                    </div>
                    <div class="postBody">
                        <div class="row g-3">
                            <div class="col-12">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="categoryFld" class="form-label">Category</label>
                                        <select id="posting_category_select"  name="category_id"  class="form-select">
                                            

                                            <option class="title" disabled="disabled" 
                                                selected="selected">Our Categories</option>
                                            <?php $__currentLoopData = $getcat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catvalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($catvalue->id); ?>"><?php echo e($catvalue->category_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"> <?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                    </div>
                                    
                                    <div class="col-lg-6">
                                        <label for="categoryFld" class="form-label">Sub Category</label>
                                        <select name="sub_category_id" class="form-select">
                                            
                                          <option class="title" disabled="disabled" selected="selected">Our Sub Categories</option>

                                        </select>
                                        <?php $__errorArgs = ['sub_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"> <?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                    </div>
                                    
                                    
                                    
                                </div>
    </div>
    <div class="col-lg-6">
        <label for="postcodeFld" class="form-label">Postcode</label>
        <input type="text" id="postcodeFld" name="postcode" class="form-control">
                <?php $__errorArgs = ['postcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"> <?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-lg-6">
        <label for="adTitle" class="form-label">Title of your ad</label>
        <input type="text" id="adTitle" name="post_title" class="form-control">
                <?php $__errorArgs = ['post_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"> <?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-12">
        <label for="descriptionFld" class="form-label">Description</label>
        <textarea id="descriptionFld" name="post_detail" class="form-control" rows="3">
            </textarea>
            <?php $__errorArgs = ['post_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"> <?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
                            
            <div class="col-lg-6">
                <label for="salaryFld" class="form-label">Price</label>
                <div class="input-group mb-3">
                    <span class="input-group-text" id="basic-addon1">£</span>
                    <input type="text" class="form-control" name="expected_price" placeholder="">
                  
                </div>
                <?php $__errorArgs = ['expected_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"> <?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    
        <div class="postHeader">
            <h4> Main photo</h4>
        </div>
        <div class="postBody">
        <div class="fileUploadCol">
            <div class="upload__box">
                <div class="upload__btn-box">
                    <label class="upload__btn">
                        <span><img src="<?php echo e(('frontend/images/upload-icon.svg')); ?>" alt="..."></span>
                        <p>Upload image</p>
                        <input type="file" data-max_length="20" name="main_image"
                            class="upload__inputfile"
                            onchange="document.getElementById('output').src = window.URL.createObjectURL(this.files[0])">
                    </label>
                </div>
                
                <img id="output" src="<?php echo e(asset('upload/no_image.jpg')); ?>" width="100" height="100">
            </div>
            </div>
        </div>
                    <?php $__errorArgs = ['main_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"> <?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>






                    
                    <div class="postHeader">
                        <h4> Select Multiple photos</h4>
                        <p>
                            Important: Add a clear and accurate photo(s) to increase the number of responses you
                            receive. You may add up to 12 pictures. Max file size 4MB.</p>
                    </div>
                    <div class="postBody">
                        <div class="fileUploadCol">
                            <div class="upload__box">
                                <div class="upload__btn-box">
                                    <label class="upload__btn">
                                        <span><img src="<?php echo e(('frontend/images/upload-icon.svg')); ?>" alt="..."></span>
                                        <p>Upload images</p>
                                        <input type="file" multiple="" data-max_length="20" name="photo_name[]"
                                            class="upload__inputfile">
                                    </label>
                                </div>
                                <div class="upload__img-wrap"></div>
                            </div>
                        </div>
                    </div>

                    <div class="postHeader">
                        <h4>Your personal info</h4>
                    </div>
                    <div class="postBody">
                        <div class="row g-3">
                            <div class="col-lg-6">
                                <label for="adTitle" class="form-label">Phone</label>
                                <input type="text" id="adTitle" name="phone" class="form-control">

                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"> <?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="form-text">This will be displayed on your ad</div>

                            </div>
                        </div>
                    </div>
                    <div class="postHeader">
                        <h4>Publish your ad </h4>
                    </div>
                    <div class="postBody">
                        <div class="checkCol">
                            <div class="mb-3 form-check">
        <input type="checkbox" class="form-check-input" id="termLbl" name="agree" value="1">
            <label class="form-check-label" for="termLbl">I agree to DoMyBidding’s <a
                    href="javascript:void(0)" target="_blank">Terms and Conditions</a>, <a
                    href="javascript:void(0)" target="_blank"> Posting Guidelines</a> and accept the
                <a href="javascript:void(0)" target="_blank">Privacy Policy</a>.</label>
                
        </div>
        <?php $__errorArgs = ['agree'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger"> <?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     
                        <button class="btn btnSecondary">Publish your ad</button>
                    </div>
                </div>
            </form>

        </div>
    </div>


</section>
<script type="text/javascript">
    $(document).ready(function () {
        $('select[name="category_id"]').on('change', function () {
            var category_id = $(this).val();
            console.log(category_id);
            if (category_id) {
                $.ajax({
                    url: "<?php echo e(url('/ajax')); ?>/" + category_id,
                    type: "GET",
                    dataType: "json",
                    success: function (data) {
                        $('select[name="sub_category_id"]').html('')
                        var d = $('select[name="sub_category_id"]').empty();
                        $.each(data, function (key, value) {
                            $('select[name="sub_category_id"]').append(
                                '<option value="' + value.id + '">' + value.subcategory_name + '</option>');
                        });
                    },
                });
            } else {
                alert('danger');
            }
        });
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.home_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Php-laravel\htdocs\1_project\domybiding\resources\views/frontend/post/index.blade.php ENDPATH**/ ?>
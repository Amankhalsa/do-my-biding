
<?php $__env->startSection('title', 'Services' ); ?>
<?php $__env->startSection('home_content'); ?>
   <div class="headerHeight"></div>
    <section>
      <div class="breadcrumbCol">
        <div class="container position-relative">
          <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">UK</li>
            </ol>
          </nav>
        </div>
      </div>
    </section>
    <section>
      <div class="proSearchCol mb-3">
        <div class="container">
          <div class="formInnerCol">
            <form action="">
              <div class="row g-1 g-lg-2">
                <div class="col-sm-4 col-xl-4">
                  <input type="text" class="form-control" placeholder="keywords">
                </div>
                <div class="col-sm-4 col-xl-4">
                  <input type="text" class="form-control" placeholder="Home">
                </div>
                <div class="col-sm-4 col-xl-4">
                  <input type="text" class="form-control" placeholder="All UK">
                </div>
                <div class="col-sm-4 col-xl-4">
                  <h5 class="formLbl mb-1">Price</h5>
                  <select class="form-select">
                    <option selected>Min</option>
                    <option value="1">Other option</option>
                  </select>
                </div>
                <div class="col-sm-4 col-xl-4 align-self-end">
                  <select class="form-select">
                    <option selected>Max</option>
                    <option value="1">Other option</option>
                  </select>
                </div>
                <div class="col-sm-4 col-xl-4 align-self-end">
                  <div class="form-check">
                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                    <label class="form-check-label" for="exampleCheck1">Ads with pics</label>
                  </div>
                </div>
                <div class="col-sm-4 col-xl-4">
                  <button class="btn btnPrimary w-100">Search</button>
                </div>
              </div>
            </form>

          </div>
        </div>
      </div>
    </section>
    <section>
      <div class="resultCol pageContent pt-0">
        <div class="container">
          <div class="propertyTopRow">
            <div class="row gy-3 gy-xl-0 align-items-center">
              <div class="col-xl-auto order-xl-last">
                <div class="filterRightCol">
                  <div class="row g-2">
                    <div class="col-sm">
                      <div class="gridListCol">
                        <ul>
                          <li><a href="javascript:void(0)" class="active"><span class="glIcon"><img src="<?php echo e(asset('frontend/images/list-icon.png')); ?>" alt="..."></span> <span class="glText">Classifieds</span></a></li>
                          <li><a href="javascript:void(0)"><span class="glIcon"><img src="<?php echo e(asset('frontend/images/grid-icon.png')); ?>" alt="..."></span> <span class="glText">Gallery</span></a></li>
                        </ul>
                      </div>
                    </div>
                    <div class="col-sm-auto">
                      <div class="sortFld">
                        <select class="form-select">
                          <option selected>Sort by:</option>
                          <option value="1">Option 1</option>
                          <option value="1">Option 2</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-xl">
                <div class="row g-0">
                  <div class="col-auto">
                    <span class="resultTitle">452 results in Buy and Sell for Home UK</span>
                  </div>
                  <div class="col">
                    <div class="resultOptions d-none d-lg-block">
                      <ul>
                        <li><a href="javascript:void(0)">Individual (275)</a></li>
                        <li><a href="javascript:void(0)">Professional (177)</a></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="propResultCol">
            
            <?php $__currentLoopData = $post_data_single_img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="listColMain">
              <a href="<?php echo e(route('frontend.add.page',$values->id )); ?>" class="blankLink"></a>
              <div class="row g-3">
                <div class="col-sm-auto">
                  <div class="listImgCol">
                    <img src="<?php echo e(asset($values->main_image)); ?>" alt="..." class="listImg">
                
                    <span class="pNumberCol"> <?php echo e(count($post_data_multi_img )); ?></span>
                
                  </div>
                </div>
                <div class="col-sm">
                  <div class="propertyContentCol">
                    <div class="propContentTopCol">
                      <h4><?php echo e($values->post_title); ?></h4>
                      <p><?php echo e($values->you_are); ?></p>
                      <span class="propPriceCol">$<?php echo e($values->expected_price); ?></span>
                      <p class="lineClamp2">
                      
                      <?php echo e(Str::limit(	$values->post_detail,250,$end='....')); ?>

                      </p>
                    </div>
                    <div class="propLocationCol lineClamp1">
                      <?php echo e($values->postcode); ?>

                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            

         
          
            <div class="crateAlertCol">
              <p>Receive email notifications for new ads matching your search criteria ..</p>
              <a href="javascript:void(0)" class="btn btnSecondary">Create an alert</a>
            </div>
            <div class="paginationCol">
              <nav aria-label="Page navigation example">
                <ul class="pagination justify-content-center">
                  <li class="page-item">
                    <a class="page-link" href="#" aria-label="Previous">
                      <span aria-hidden="true">&laquo;</span>
                    </a>
                  </li>
                  <li class="page-item active"><a class="page-link" href="#">1</a></li>
                  <li class="page-item"><a class="page-link" href="#">2</a></li>
                  <li class="page-item"><a class="page-link" href="#">3</a></li>
                  <li class="page-item">
                    <a class="page-link" href="#" aria-label="Next">
                      <span aria-hidden="true">&raquo;</span>
                    </a>
                  </li>
                </ul>
              </nav>
            </div>
            <div class="borderCol">
              <div class="tagsCol">
                <h3>Categories</h3>
                <ul>
                  <li>
                    <a href="javascript:void(0)">Household goods</a>
                  </li>
                  <li>
                    <a href="javascript:void(0)">Furniture</a>
                  </li>
                  <li>
                    <a href="javascript:void(0)">Household goods</a>
                  </li>
                  <li>
                    <a href="javascript:void(0)">Household goods</a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="borderCol">
              <div class="tagsCol">
                <ul>
                  <li>
                    <a href="javascript:void(0)">North east</a>
                  </li>
                  <li>
                    <a href="javascript:void(0)">London</a>
                  </li>
                  <li>
                    <a href="javascript:void(0)">North east</a>
                  </li>
                  <li>
                    <a href="javascript:void(0)">London</a>
                  </li>
                </ul>
              </div>
              <div class="moreLocationCol">
                <a href="javascript:void(0)">More locations</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('frontend.home_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Php-laravel\htdocs\1_project\domybiding\resources\views/frontend/services.blade.php ENDPATH**/ ?>
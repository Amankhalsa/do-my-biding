<?php 
$get_logo = DB::table('sitelogos')->first();
?>
<header>
      <div class="headerColMain">
        <div class="container">
          <div class="row g-2 align-items-center">
            <div class="col-auto">
              <div class="logoCol">
                <a href="<?php echo e(url('/')); ?>">
          <img src="<?php echo e((!empty($get_logo->logo)? asset($get_logo->logo) : asset($get_logo->logo))); ?>">
                </a>
              </div>
            </div>
            <div class="col">
              <div class="navigationCol">
                <div class="navCol text-center">
                  <ul>
                    <li>
                      <a href="javascript:void(0)">
                        <span class="menuIcon"><img src="<?php echo e(asset('frontend/images/menu-icon-1.png')); ?>" alt=""></span>
                        <span class="menuText">Get bidding!</span>
                      </a>
                    </li>
                    <li>
                      <a href="<?php echo e(route('add.page.view')); ?>">
                        <span class="menuIcon"><img src="<?php echo e(asset('frontend/images/menu-icon-2.png')); ?>" alt=""></span>
                        <span class="menuText">Post a Service</span>
                      </a>
                    </li>
                    <li>
                      <a href="<?php echo e(route('serives.page')); ?>" class="mLink2">
                        <span class="menuIcon"><img src="<?php echo e(asset('frontend/images/menu-icon-3.png')); ?>" alt=""></span>
                        <span class="menuText">Browse Services</span>
                      </a>
                    </li>
                    <li>
                      <a href="javascript:void(0)" class="mLink2">
                        <span class="menuIcon"><img src="<?php echo e(asset('frontend/images/menu-icon-4.png')); ?>" alt=""></span>
                        <span class="menuText">Service Providers</span>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-auto">
              <div class="headerRightCol">
                <div class="row align-items-center g-0">
                  <div class="col">
                    <div class="logCol">
                      <ul>
                        <li>
                             <?php if(auth()->guard()->check()): ?>
                          <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <a href="route('logout')"onclick="event.preventDefault();this.closest('form').submit();">
                                <?php echo e(__('Log Out')); ?>

                            </a>
                        </form>
                        <?php else: ?>
                          <a href="<?php echo e(route('login')); ?>">login</a>

                        </li>
                        <li>
                          <a href="<?php echo e(route('register')); ?>">register</a>
                        </li>
                         <?php endif; ?>
                      </ul>
                    </div>
                  </div>
                  <div class="col-auto d-lg-none">
                    <div class="toggle ps-3">
                      <a href="javascript:void(0)" class="navTrigger"><img src="<?php echo e(asset('frontend/images/nav-toggle.svg')); ?>" alt="Image Not Found"></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header><?php /**PATH E:\Php-laravel\htdocs\1_project\domybiding\resources\views/frontend/body/header.blade.php ENDPATH**/ ?>